package hibernate;

import java.util.List;


//this is my testing class to see if the functions are working correctly before scan is inputed 
public class HibernateMain {
	
	public static void main(String[] args) { 
		
		//checking if DAO and connections are working 
		
//		Student student = new Student(); 
//		StudentDAO studentDAO = new StudentDAO(); 
//		Course course = new Course(); 
//		CourseDAO courseDAO = new CourseDAO(); 
		 
		
		//HIBERNATE WORKING WITH INSERTING AND NOT 
		
		//inserting a student
//		student.setSEmail("hibernate@email.com");
//		student.setSName("Testing Hibernate");
//		student.setSPass("pass");
//		studentDAO.insert(student);
		
		//inserting a new course 
//		course.setCName("Hibernate Checking");
//		course.setCInstructorName("Hibernate");
//		courseDAO.insert(course);
		
		//deleting the hibernate test cases from database 
//		course = courseDAO.findById(13); 
//		courseDAO.delete(course);
//	
//		student = studentDAO.findById(15); 
//		studentDAO.delete(student);
		
		//checking if the getAllCourses Print
		
		//courseDAO.getAllCourses();
		
		//checking getAllStudents 
		//studentDAO.getAllStudents();
		
//		List<Student> name = studentDAO.getStudentByEmail("test@testing.com");
//		for( Student s : name) {
//			System.out.println(s);
//		}
		
		//checking valid user 
		
		//System.out.println(studentDAO.validateStudent("test@testing", "pass")); 
		
		//checking if student course DAO works 
		
		
//		StudentCourse sc = new StudentCourse(); 
//		StudentCourseDAO dao = new StudentCourseDAO(); 
//		Student student = new Student(); 
//		StudentDAO sDAO = new StudentDAO(); 
//		Course course = new Course (); 
//		CourseDAO cDAO = new CourseDAO(); 
//		
//		student = sDAO.findById(11); 
//		course = cDAO.findById(2); 
//		
//		
//		sc.setStudent(student);
//		sc.setCourse(course);
//		
//		dao.insert(sc);
		
		//checking if register for class function is working
	
		//StudentDAO sDAO = new StudentDAO(); 
//		
		//sDAO.registerStudentToCourse(4, 11);
		
		//checking is get all student course works
		
		//List<Student> student =  sDAO.getStudentByEmail("test@testing.com"); 
		
		
		//System.out.println(id);
		
		
		//System.out.println(sDAO.getStudentCourses(11)); 

	}

}
